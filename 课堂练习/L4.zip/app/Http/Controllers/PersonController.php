<?php

namespace App\Http\Controllers;

// use Illuminate\Support\Facades\Request;

use Illuminate\Http\Request;

class PersonController extends Controller
{
    public function test(Request $request)
    {
        dd($request->old());
    }
    public function index(Request $request)
    // public function index()
    {
        // 设置响应
        // 显示文件内容
        return response()->file('test2.pdf');
        // 
        // 文件下载（默认根目录是 public目录）
        return response()->download('robots.txt', 'mydownload.txt');
        
        // 
        // response()辅助函数，返回ResponseFactory类实例对象
        // 响应JSON
        // return json_encode([
        //     'name'  =>  'test',
        //     'age'   =>  18
        // ]);
        
        return response()->json([
            'name'  =>  'test',
            'age'   =>  18
        ]);

        // 
        // 重定向
        // return redirect()->to('photo');
        return redirect()->away('http://www.baidu.com');

        // 存储一次性数据
        $request->flashOnly('id');

        return '<a href="person/test">jump</a>';

        // 获取请求参数
        dd($request->all());
        dd($request->input('id'));

        // 获取请求路径
        dump($request->path());
        dump($request->url());
        dump($request->fullUrl());

        // dd()：输出变量的详细信息，程序结束
        // dump()：输出变量的详细信息，程序继续
        // dd()  ==  dump(); exit;
        // $request = new Request();
        // 
        // 门面类形式
        // $params = Request::all();
        // dd($params);

        // dd($request);
    }
}
