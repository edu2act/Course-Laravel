<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     * 所有服务提供者绑定后，才调用该方法
     * 比如，视图间共享数据，在此处书写
     *
     * @return void
     */
    public function boot()
    {
        $data = [
            'name'  =>  'test',
            'age'   =>  18,
        ];
        view()->share($data);
        // View::share($data);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton('MyUsers', function($app) {
            return new \App\User();
        });
    }
}
