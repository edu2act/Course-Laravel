<?php
return [
    'hello' =>  'How are you?',
];