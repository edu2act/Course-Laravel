<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>photos - @yield('title')</title>
</head>
<body>
    <div id="header">
        @section('header')
            This is header area!
        @show
    </div>
    <div id="content">
        @yield('content')
    </div>
    <div id="footer">
        this is my footer area!
    </div>
</body>
</html>