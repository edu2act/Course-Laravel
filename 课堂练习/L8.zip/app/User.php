<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * 每一个用户，有一条用户详情
     */
    public function userInfo()
    {
        return $this->hasOne('App\UserInfo');
    }

    /**
     * 每一个用户可能发表了多篇日志
     */
    public function posts()
    {
        return $this->hasMany('App\Post');
    }
}
