<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>test</title>
</head>
<body>
    name => <?php echo e($name); ?>

    age => <?php echo e($age); ?>

</body>
</html>