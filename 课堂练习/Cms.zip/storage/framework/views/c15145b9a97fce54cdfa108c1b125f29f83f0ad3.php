<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    <body>

        <form action="/" method="post">
            <input type="hidden" name="_method" value="delete">
            <?php echo e(csrf_field()); ?>


            <input type="submit" value="submit" />
        </form>

        <div>
            <a href="">get hello page</a>
        </div>

    </body>
</html>
