<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('newss', function(Blueprint $table) {
            $table->increments('id');   // id字段
            $table->string('title');    // varchar类型
            $table->text('content');    // text类型
            $table->timestamps();       // 添加created_at和updated_at列
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('newss');
    }
}
