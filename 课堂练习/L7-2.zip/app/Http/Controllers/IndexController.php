<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Illuminate\Support\Facades\DB;
use DB;
use Session;

class IndexController extends Controller
{
    public function index(Request $request)
    {
        // // 定义每一页的个数
        // $pageSize = 5;
        // // 获取当前是第几页？
        // $page = $request->get('page', 1);
        // // 数据表中的偏移量
        // $offset = ($page - 1) * $pageSize;

        // // 查询构造器方式获取分页数据
        // $results = DB::table('members')->offset($offset)->limit($pageSize)->get()->toArray();
        // 
        // 读取配置项
        $pageSize = config('page.page_size');
        // Laravel中提供的分页支持
        // $results = DB::table('members')->paginate(1);
        $results = DB::table('members')->simplePaginate($pageSize);

        // 交给视图显示
        return view('index')->with('members', $results);
    }

    public function login(Request $request)
    {
        // 把用户信息写入到session中
        // 方法1：Request对象
        $request->session()->put('name', '张三');
        // 方法2：session辅助函数
        session(['age' => 18]);
        // 方法3：Session门面类
        Session::put('sex', '男');
        // 测试有没有session
        // dd(Session::all());
        dump(Session::all());
    }

    public function testsession()
    {
        // 获取session数据
        // session辅助函数
        $name = session('name');
        // session门面
        $age = Session::get('age');
        // 获取所有session数据
        $sDatas = Session::all();
        // dd($sDatas);
        dump($sDatas);
    }
}
