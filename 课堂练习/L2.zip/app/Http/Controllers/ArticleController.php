<?php
namespace App\Http\Controllers;

class ArticleController extends Controller
{
    public function index()
    {
        return 'article/index';
    }

    public function view($id, $title)
    {
        return 'article-view-' . $id . '-title-' . $title;
    }
}