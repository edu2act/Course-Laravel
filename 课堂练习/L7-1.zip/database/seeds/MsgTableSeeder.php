<?php

use Illuminate\Database\Seeder;

class MsgTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($index = 1; $index <= 20; $index++) {
            DB::table('msgs')->insert([
                'title' =>  "第{$index}条留言",
                'content'   =>  "第{$index}条留言的内容",
                'add_time'  =>  date('Y-m-d H:i:s')
            ]);
        }
    }
}
