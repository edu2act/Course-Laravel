<?php

use Illuminate\Database\Seeder;

class MemberInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 1; $i <= 10; $i++) { 
            $m = new App\Model\MemberInfo();
            $m->phone = 'phone-' . $i;
            $m->member_id = $i;
            $m->save();
        }
    }
}
