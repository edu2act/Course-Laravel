<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Member extends Model
{
    // 引入Traits
    use SoftDeletes;
    // 允许软删除字段
    protected $dates = ['deleted_at'];

    public function memberinfo()
    {
        return $this->hasOne('App\Model\MemberInfo');
    }

    public function articles()
    {
        return $this->hasMany('App\Model\Article', 'member_id');
    }

    public function roles()
    {
        // 当前表是 Member
        // 参数1：角色表
        // 参数2：中间表（关联关系表）
        // 参数3：当前表主键在中间表中的字段名
        // 参数4：角色表主键在中间表中的字段名
        return $this->belongsToMany('App\Model\Role', 'role_members', 'member_id', 'role_id');
    }
}
