<?php

namespace App\Http\Controllers;

// use Illuminate\View\View;

use Illuminate\Support\Facades\View;

class UserController extends Controller
{
    public function index()
    {
        
    }
}
