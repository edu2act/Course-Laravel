<?php

namespace App\Http\Controllers;

use App\Model\Member;
use App\Model\MemberInfo;
use Illuminate\Http\Request;
use Session;

class MemberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // return Member::all();
        // 获取所有记录
        $ms = Member::all();    // Collection集合
        // dd($ms->toArray());     // 数组形式
        // dd($ms->toJson());      // JSON字符串
        // foreach循环遍历
        dd($ms);

        // 获取多对多关系数据
        $m = Member::find(1);
        dd($m->roles);

        // 由文章获取其作者信息
        $a = \App\Model\Article::find(1);
        dd($a->member->name);

        // 获取一对多关系数据
        $m = Member::find(1);
        // dd($m->articles);
        foreach ($m->articles as $value) {
            dump($value->title);
        }
        exit;

        $mi = MemberInfo::find(5);
        dd($mi->member->name);

        // 测试一对一关系
        // 首先获取member对象
        // $member = Member::find(5);
        // // 访问关联模型（通过动态属性形式）
        // dd($member->memberinfo->phone);

        // 获取所有记录
        // dd(Member::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Member  $member
     * @return \Illuminate\Http\Response
     */
    public function show(Member $member)
    {
        // 测试一对一关系

        // 测试软删除
        // $r = $member->delete();
        // dd($r);
        // dd($member);
        // 首先获取id
        // $id = app('request')->get('id');
        // 获取id所对应的记录
        // $member = Member::find($id);
        // 使用记录
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Member  $member
     * @return \Illuminate\Http\Response
     */
    public function edit(Member $member)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Member  $member
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Member $member)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Member  $member
     * @return \Illuminate\Http\Response
     */
    public function destroy(Member $member)
    {
        //
    }
}
