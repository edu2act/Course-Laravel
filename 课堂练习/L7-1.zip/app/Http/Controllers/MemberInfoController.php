<?php

namespace App\Http\Controllers;

use App\Model\MemberInfo;
use Illuminate\Http\Request;

class MemberInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\MemberInfo  $memberInfo
     * @return \Illuminate\Http\Response
     */
    public function show(MemberInfo $memberInfo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\MemberInfo  $memberInfo
     * @return \Illuminate\Http\Response
     */
    public function edit(MemberInfo $memberInfo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\MemberInfo  $memberInfo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MemberInfo $memberInfo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\MemberInfo  $memberInfo
     * @return \Illuminate\Http\Response
     */
    public function destroy(MemberInfo $memberInfo)
    {
        //
    }
}
