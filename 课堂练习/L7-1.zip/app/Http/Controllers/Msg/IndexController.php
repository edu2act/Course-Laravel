<?php

namespace App\Http\Controllers\Msg;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // 获取查询构造器对象
        $builder = \DB::table('msgs');
        // dd($builder);
        // 使用查询构造器获取记录
        $results = $builder->get();
        // 获取所有记录
        // $results = \DB::select('select * from msgs where id > 10');
        // dd($results);
        // 显示视图
        return view('msg.index')->with('msgs', $results);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('msg.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // 先获取请求数据
        $msg = [];
        $msg['title']   =   $request->get('title');
        $msg['content'] =   $request->get('content');
        $msg['add_time']    =   date('Y-m-d H:i:s');
        // 插入到数据表中
        $r = \DB::table('msgs')->insert($msg);
        dd($r);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = \DB::table('msgs')->where('id', '=', $id)->first();
        dd($result);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // 获取当前记录
        $result = \DB::table('msgs')->where('id', '=', $id)->first();
        // 显示视图
        return view('msg.edit')->with('msg', $result);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // dd($id);
        // $r = \DB::table('msgs')->delete($id);
        $r = \DB::table('msgs')->where('id', '=', $id)->delete();
        // dd($r);
        if ($r) {
            // 删除成功
            return redirect()->to('/msgs');
        }
    }
}
