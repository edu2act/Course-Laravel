<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class NewsController extends Controller
{
    public function test()
    {
        return view('news.test');
    }

    public function index()
    {
        // 测试自己注册的服务
        // $obj = app('MyUsers');
        // dd($obj);

        // $data = [
        //     'name'  =>  'test',
        //     'age'   =>  18,
        // ];
        // return view('news.index')->with($data);
        return view('news.index')->with('users', [1, 2, 3])->with('obj', new \App\User());

        // return view('news.index')->with('name', 'test');
        // return View::make('news.index');

        // $view = view(); // Factory对象
        // $view = view('news.index'); // View对象
        // dd($view);
        // 
        // IOC容器形式
        // $app = app();   // Application对象，容器对象
        // $view = app('view');    // 从容器中获取对象
        // dd($view);
    }
}
