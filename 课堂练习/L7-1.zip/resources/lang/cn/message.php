<?php
return [
    'hello' =>  '你好！',
];