
@extends('news.layout')

{{-- 用来替换父视图中的 yield指令 --}}
@section('content')
name = {{ $name }}
age = {{ $age }}
<br />
{{-- 数组元素（下标形式访问） --}}
{{ $users[0] }}
{{-- 对象（使用 -> 访问） --}}
tmp = {{ $obj->tmp }}

{{-- 多语言支持 --}}
@lang('message.hello')

@stop