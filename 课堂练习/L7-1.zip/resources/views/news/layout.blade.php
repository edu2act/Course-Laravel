<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>layout view</title>
</head>
<body>
    <div id="header">
        这里是导航栏
    </div>
    <div id="content">
        {{-- 把该处内容替换为子视图中指定section=content的内容 --}}
       @yield('content') 
    </div>
    <div id="footer">
        这里是版权信息部分
    </div>
</body>
</html>