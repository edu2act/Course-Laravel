@extends('news.layout')

@section('content')
name = {{ $name }}
age = {{ $age }}
time = {{ date('Y-m-d H:i:s') }}
<br />
csrf_token = {{ csrf_token() }}
{{ csrf_field() }}
method('post') = {{ method_field('post') }}

collegue = {{ $collegue or '河北师范大学' }}
@stop
{{-- @show --}}
{{-- 子视图一般使用@stop结束，若使用@show结束，会出现重复内容 --}}