<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>get news request</title>
</head>
<body>
    <!-- <form action="/news" method="post"> -->
    <form action="/news" method="post">
        <!-- csrf认证问题 -->
        <?php echo csrf_field(); ?>
        <!-- 表单伪造 -->
        <?php echo method_field('delete'); ?>
        <!-- 提交按钮 -->
        <input type="submit" value="提交" />
    </form>
</body>
</html>