<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>laravel</title>
</head>
<body>
    hello laravel 5.4
</body>
</html>