
<ul>
@foreach ($msgs as $element)
    <li>
        <a href="/msgs/{{$element->id}}">{{ $element->title }}</a>
        <span>
            {{ $element->add_time }}
        </span>
        <span>
            <a href="/msgs/{{$element->id}}/edit">更新</a>
        </span>
        <span>
            <form action="/msgs/{{$element->id}}" method="post">
                {{ method_field('delete') }}
                {{ csrf_field() }}
                <input type="submit" value="删除" />
            </form>
        </span>
    </li>
@endforeach
</ul>