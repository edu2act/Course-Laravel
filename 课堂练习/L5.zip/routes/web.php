<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function() {
    return view('welcome');
})->name('rootPath');

// 由闭包函数处理路由
Route::get('/news', function() {
    return view('news');
})->name('news');

Route::post('/news', function() {
    return 'post news';
});

Route::delete('/news', function() {
    return 'delete news';
});

// 定义控制器动作路由
Route::get('/article', 'ArticleController@index');

// 定义路由参数

Route::get('/article/{id}/{title}', [
    'as'    =>  'articleView',
    'uses'  =>  'ArticleController@view'
]);
Route::get('/news/view/{id?}', [
    'as'    =>  'newsView',
    'uses'  =>  function($id = 0) {
        return 'news-view-' . $id;
    }
]);
Route::get('/news/{id}', function($id) {
    return 'news-' . $id;
})->where(['id'=>'[0-9]+']);

// 绑定资源控制器
Route::resource('photo', 'PhotoController');

Route::get('/person', 'PersonController@index');
Route::get('/person/test', 'PersonController@test');

Route::get('/news', 'NewsController@index');
Route::get('/news/test', 'NewsController@test');

Route::resource('/msgs', 'Msg\IndexController');
