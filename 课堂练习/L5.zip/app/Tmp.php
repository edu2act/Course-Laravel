<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tmp extends Model
{
    //
}
