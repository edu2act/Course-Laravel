
<form action="/msgs" method="post">
    {{ csrf_field() }}
    <p>
        title: <input type="text" name="title" />
    </p>
    <p>
        content: <textarea name="content"></textarea>
    </p>
    <p>
        <input type="submit" value="add" />
    </p>
</form>