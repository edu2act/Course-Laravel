@extends('photo.layout')

@section('title', 'Page Title')

@section('header')
    {{-- @parent --}}
    <p>this is appended to the master header.
@endsection

@section('content')
    <p>this is my body content.</p>
@endsection