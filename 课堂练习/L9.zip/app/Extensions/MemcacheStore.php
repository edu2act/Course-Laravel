<?php
namespace App\Extensions;

use Illuminate\Contracts\Cache\Store;

class MemcacheStore implements Store
{
    protected $_memcache;

    public function __construct()
    {
        $this->_memcache = new \Memcache();
        $this->_memcache->connect('127.0.0.1', 11211);
    }

    public function get($key)
    {
        return $this->_memcache->get($key);
    }

    public function many(array $keys)
    {
        $results = [];
        foreach ($keys as $k) {
            $results[] = $this->_memcache->get($k);
        }
        return $results;
    }

    public function put($key, $value, $minutes)
    {
        return $this->_memcache->set($key, $value, 0, $minutes);
    }

    public function putMany(array $values, $minutes)
    {
        foreach ($values as $k => $v) {
            $this->_memcache->set($k, $v, 0, $minutes);
        }
    }

    public function increment($key, $value = 1)
    {
        return $this->_memcache->increment($key, $value);
    }

    public function decrement($key, $value = 1)
    {

    }

    public function forever($key, $value)
    {
        return $this->_memcache->set($key, $value);
    }

    public function forget($key)
    {
        return $this->_memcache->delete($key);
    }

    public function flush()
    {
        return $this->_memcache->flush();
    }

    public function getPrefix()
    {
        
    }
}