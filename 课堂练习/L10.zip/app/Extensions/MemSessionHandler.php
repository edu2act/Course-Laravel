<?php
namespace App\Extensions;

class MemSessionHandler implements \SessionHandlerInterface
{
    protected $_memcache = null;

    public function __construct()
    {
        $this->_memcache = new \Memcache();
        $this->_memcache->connect('127.0.0.1', 11211);
    }

    public function open($save_path, $name)
    {
        
    }

    public function read($session_id)
    {
        return $this->_memcache->get($session_id);
    }

    public function write($session_id, $session_data)
    {
        return $this->_memcache->set($session_id, $session_data);
    }

    public function destroy($session_id)
    {
        return $this->_memcache->delete($session_id);
    }

    public function gc($maxlifetime)
    {
        return true;
    }

    public function close()
    {
        return $this->_memcache->close();
    }
}