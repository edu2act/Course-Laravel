<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use View;
use App\Menu;
use Session;
use App\Extensions\MemSessionHandler;
use Cache;
use App\Extensions\MemcacheStore;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        // 视图间共享数据
        View::share('menus', 
            Menu::where('isDisplay', '=', 1)->orderBy('sortNumber', 'desc')->get());
        // 扩展Session驱动
        Session::extend('memcache', function() {
            return new MemSessionHandler();
        });
        // 扩展Cache驱动
        Cache::extend('memcache', function() {
            return Cache::repository(new MemcacheStore());
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
