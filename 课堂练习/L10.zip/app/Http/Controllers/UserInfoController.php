<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

class UserInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        // dd($user->userInfo->toArray());
        return view('userinfos.index')->with('userinfo', $user);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('userinfos.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $userinfo = \App\UserInfo::find($id);
        return view('userinfos.edit')->with('userinfo', $userinfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // 创建修改参数
        $userInfo = \App\UserInfo::find($id);
        if (!$userInfo) {   // 原始记录不存在 
            $userInfo = new \App\UserInfo();
            $userInfo->id = $id;
        }
        $userInfo->trueName = $request->get('trueName');
        $userInfo->idcard = $request->get('idcard');
        $userInfo->user_id = $request->get('user_id');

        // 文件上传
        $filePath = $request->file('image')->store('photos');
        $userInfo->image = '/uploads/' . $filePath;
        // 修改数据表中的数据
        $result = $userInfo->save();
        // 后续处理
        if ($result) {
            return redirect('/userinfos');
        } else {
            return back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
