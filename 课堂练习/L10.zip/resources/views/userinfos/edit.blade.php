@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">修改用户信息</div>

                <div class="panel-body">
                    <form action="/userinfos/{{Auth::user()->id}}" method="post" enctype="multipart/form-data">
                        <p>
                            {{csrf_field()}}
                            {{method_field('PUT')}}
                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}" />
                        </p>
                        <p>
                            姓名：<input type="text" name="trueName" value="{{$userinfo->trueName or ''}}" />
                        </p>
                        <p>
                            身份证号：<input type="text" name="idcard" value="{{$userinfo->idcard or ''}}" />
                        </p>
                        <p>
                            修改头像：<img src="{{$userinfo->image or ''}}" />
                            <input type="file" name="image" />
                        </p>
                        <p>
                            <input type="submit" value="提交" />
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection