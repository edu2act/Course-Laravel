@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">用户详细信息</div>

                <div class="panel-body">
                    <p>用户名：{{$userinfo->name}}</p>
                    <p>电子邮箱：{{$userinfo->email}}</p>
                    <p>姓名：{{$userinfo->userInfo->trueName or ''}}</p>
                    <p>身份证号：{{$userinfo->userInfo->idcard or ''}}</p>
                    <p>头像：<img src="{{$userinfo->userInfo->image or ''}}" /></p>
                    <p><a href="/userinfos/{{$userinfo->id}}/edit">修改用户信息</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection