<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>mail</title>
</head>
<body>
    Hello, <span style="color: red;">{{$name}}</span>！
    <div>
        <a href="{{url('/')}}">跳转到首页</a>
    </div>
</body>
</html>