<?php

use App\Post;
use Illuminate\Database\Seeder;

class PostTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // 创建数据库模型对象
        $post = new Post();
        for ($i = 1; $i < 51; $i++) {
            $post->create([
                'title' =>  'post-' . $i,
                'content'   =>  'content-' . $i,
                'user_id' => $i % 3 + 1,
            ]);
        }
    }
}
